import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5101,
    proxy: {
      '/api': {
        target: 'http://localhost:5102',
        changeOrigin: true
      },
      '/uploads': {
        target: 'http://localhost:5102',
        changeOrigin: true
      }
    }
  },
  build: {
    outDir: 'dist'
  }
})
